package com.clients.soap;

public interface EmployeeService {
	public Employee getEmployeeById(String id);
}

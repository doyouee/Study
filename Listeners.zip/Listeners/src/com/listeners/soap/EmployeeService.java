package com.listeners.soap;

import javax.jws.WebService;

@WebService
public interface EmployeeService {
	public Employee getEmployeeById(String id);
}
